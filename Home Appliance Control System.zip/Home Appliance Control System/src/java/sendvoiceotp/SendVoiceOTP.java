/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sendvoiceotp;


import Controller.Controller;
import okhttp3.*;


/**
 *
 * @author Ahuja
 */
public class SendVoiceOTP {
    
    public static void sendVoiceOTP(String number, String otp) {
      
        try{
            
            Controller controller = new Controller();
            
            String api = controller.getVoiceOTPCredentials().get("API key").toString();
            
            /*
            
            
            OkHttpClient client = new OkHttpClient();

            Request request = new Request.Builder()
              .url("http://2factor.in/API/V1/" + api + "/SMS/" + number + "/" + otp)
              .get()
              .addHeader("content-type", "application/x-www-form-urlencoded")
              .build();

            Response response = client.newCall(request).execute();


            */
            
            OkHttpClient client = new OkHttpClient();

            MediaType mediaType = MediaType.parse("application/octet-stream");
            RequestBody body = RequestBody.create(mediaType, "{}");
            Request request = new Request.Builder()
              .url("http://2factor.in/API/V1/" + api + "/VOICE/" + number + "/" + otp )
              .get()
              .build();
            
            
            Response response = client.newCall(request).execute();
            
           
        }
        catch(Exception e){
            System.err.println(e);
        }
        
        
    }
    
    
    
    
}

