package Controller;

import Connection.MyConnection;
import com.mongodb.BasicDBList;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteResult;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import static java.lang.System.in;
import static java.lang.System.out;
import java.util.Date;


/**
 * Created by Ahuja on 05-Aug-17.
 */
public class Controller {

    public MongoClient mongoClient = MyConnection.getConnection();
    //selecting database and collection
    public DB db = mongoClient.getDB("test");
    public DBCollection dbCollection = db.getCollection("login");

    
    public boolean loginCheck( String name , String password ){

        
        boolean flag = false ; //true only when login is confirmed        

        // creating new object
        DBObject query = new BasicDBObject("_id", name).append("password",password);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = dbCollection.findOne(query);
        
        if (d1!=null){
            flag = true ;
        }

        return flag ;
    }


    public boolean registerUser(String firstName,String lastName,String email,String mobile,String name,String password){

        boolean flag = false;

        try {

            BasicDBObject doc = new BasicDBObject("_id", name).append("password", password).append("First Name", firstName).append("Last Name", lastName).append("Email", email).append("Mobile", mobile);
            BasicDBObject docForDevices = new BasicDBObject("_id", name).append("Number of devices", 3).append("Bulb Status", "OFF").append("Fan Status", "OFF").append("Microwave Status", "OFF").append("Connected", "NO").append("Device Temprature", "0").append("Room Temprature", "0").append("Room Humidity", "0");
            DBCollection dbCollectionForDevices = db.getCollection("devices");
            
            WriteResult insert = dbCollection.insert(doc);
            WriteResult insert1 = dbCollectionForDevices.insert(docForDevices);
            
            flag = true;
        }
        catch (Exception e){
            System.out.println(e);
        }

        return flag;
    }

    public DBObject documentDetails(String id){
        

        // creating new object
        DBObject query = new BasicDBObject("_id", id);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = dbCollection.findOne(query);

        if (d1!=null)
            return d1;
        else 
            return null;
    }

    
    public DBObject getDeviceDetails(String id){
        
        DBCollection coll = db.getCollection("devices");


        // creating new object
        DBObject query = new BasicDBObject("_id", id);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = coll.findOne(query);

        if (d1!=null)
            return d1;
        else return null;
    }

    
    public void updateOneField(String databaseName , String collectionName , String queryKey , String queryValue ,  String updateKey , String updateValue){
        
        MongoClient mongoClient1 = MyConnection.getConnection();
        //selecting database and collection
        DB db1 = mongoClient1.getDB(databaseName);
        DBCollection dbCollection1 = db1.getCollection(collectionName);
        
        WriteResult update = dbCollection1.update(new BasicDBObject(queryKey, queryValue) , new BasicDBObject("$set", new BasicDBObject(updateKey, updateValue)));
        
    }

    
    public String getDeviceStatus(String databaseName , String collectionName , String queryKey , String queryValue ,String deviceName){
        
        // creating new object
        DBObject newQuery = new BasicDBObject(queryKey, queryValue);

        DBCollection newDBCollection = db.getCollection("devices");
        // resultant document fetched by satisfying the criteria
        DBObject newDBObject = newDBCollection.findOne(newQuery);
        
        return (String) newDBObject.get(deviceName);
    }
    
    
    public boolean isUserValid( String userName , String email ){
        
        /*returns true if document is found matching the username and email
         *used for forgot password servlet
        */
        boolean flag = false ; //true only when login is confirmed        

        // creating new object
        DBObject query = new BasicDBObject("_id" , userName).append("Email" , email);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = dbCollection.findOne(query);

        if (d1!=null){
            flag = true ;
        }


        return flag ;
        
    }
    
    
    public boolean setNewPassword(String userName , String password){
        
        // creating new object
        DBObject query = new BasicDBObject("_id", userName);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = dbCollection.findOne(query);

        if (d1!=null){
            updateOneField("test", "login", "_id", userName, "password", password);
            return true;
        }
        else{   
            
            return false;
        }
    }
    
    
    public void upadateUserDetails( String userName , String email , String age , String location ){
        updateOneField("test", "login", "_id", userName , "Email", email);
        updateOneField("test", "login", "_id", userName , "Age", age);
        updateOneField("test", "login", "_id", userName , "Location", location);
        
    }
    
    
    
    public boolean saveImage(){
        
        try {
            DBCollection dbCollectionPhoto = db.getCollection("photos");
            
            String newFileName = "BulbImage";
            File imageFile = new File("C:\\Users\\Ahuja\\OneDrive\\Documents\\NetBeansProjects\\Home Appliance Control System\\web\\picture\\bulb.jpg");
            
            GridFS gfsPhoto = new GridFS(db, "photo");
            GridFSInputFile gfsFile = gfsPhoto.createFile(imageFile);
            gfsFile.setFilename(newFileName);
            gfsFile.save();
            return true;
            
        } catch (Exception ex) {
            System.out.println(ex);
            return false;
        }
        
    }

    /*
    public String getImage(){
        try{
            String newFileName = "BulbImage";
            GridFS gfsPhoto = new GridFS(db, "photos");
            GridFSDBFile imageForOutput = gfsPhoto.findOne(newFileName);
            System.out.println(imageForOutput);
            GridFS fs = new GridFS( db );
            GridFSDBFile mongoOut = fs.findOne( new BasicDBObject( "filename" , newFileName ));
            file = File.createTempFile("fileName", ".png");
            imageForOutput.writeTo(file);
            //FileOutputStream outputImage = new FileOutputStream("C:/Temp/bearCopy.bmp");
            out.print(file.canExecute());
            //outputImage.close();
            
            return file.getName();

        
        }
        catch(Exception e){
            return null;
        }
    }
*/


    
    
    public static String getAlldevicesStatus(String userName){
        String value1,value2,value3;
        StringBuilder status = new StringBuilder("bfm");
        
        // creating new object
        DBObject newQuery = new BasicDBObject("_id", "ahujapiyush22");

        MongoClient mongoClient = MyConnection.getConnection();
        DB db = mongoClient.getDB("test");
        DBCollection newDBCollection = db.getCollection("devices");
        // resultant document fetched by satisfying the criteria
        DBObject newDBObject = newDBCollection.findOne(newQuery);
        
        value1 = newDBObject.get("Bulb Status").toString();
        value2 = newDBObject.get("Fan Status").toString();
        value3 = newDBObject.get("Microwave Status").toString();
        
        if(value1.equalsIgnoreCase("ON"))
        { status.setCharAt(0,'1'); }
        else 
            { status.setCharAt(0,'0'); }
        
        if(value2.equalsIgnoreCase("ON"))
        { status.setCharAt(1,'1'); }
        else 
            { status.setCharAt(1 ,'0'); }
        
        if(value3.equalsIgnoreCase("ON"))
        { status.setCharAt(2,'1'); }
        else 
            { status.setCharAt(2,'0'); }
        
        
        
        return status.toString();
    }
    
    
    public boolean addNewQuery( String _id , String message , Date date){
        
        //if first query from user then create new document
        
        DBObject queryDocument = new BasicDBObject("_id", _id).append("Start Date", date);//append("Message", message ).append("Date", date);
        
        
        MongoClient mongoClient1 = MyConnection.getConnection();
        
        //selecting database and collection
        DB db1 = mongoClient1.getDB("test");
        DBCollection dbCollection1 = db1.getCollection("queries");
        
        DBObject qyery = new BasicDBObject("_id", _id);
        //if null then first document else document exists
        if( dbCollection1.findOne( qyery ) == null ){
            WriteResult update = dbCollection1.insert(queryDocument);
            
        }
        
        //add message to array in existing document
        BasicDBObject newObject = new BasicDBObject();
        newObject.put("Message", message);
        newObject.put("Date", date);
        dbCollection1.update(qyery, new BasicDBObject(
                "$push", new BasicDBObject("queries", newObject)), false,
                false);        

        
        
        return true;
    }
    
    public boolean isConnected(String userName){
        DBCollection dbCollectionForDevices = db.getCollection("devices");
        DBObject query = new BasicDBObject("_id", userName);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = dbCollectionForDevices.findOne(query);
        if(d1.get("Connected").equals("YES"))
            return true;
        else
            return false;
    }
    
    
    //method for retriving credentials for sending sms
    public DBObject getSMSCredentials(){
        return db.getCollectionFromString("BulkSMSCredentials").findOne();
    }
    
    public DBObject getVoiceOTPCredentials(){
        return db.getCollectionFromString("2FactorSMSCredentials").findOne();
    }
}
