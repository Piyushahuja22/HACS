/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import Controller.Controller;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import sendemail.SendEmail;
import static sendvoiceotp.SendVoiceOTP.sendVoiceOTP;

/**
 *
 * @author Ahuja
 */
public class forgotPasswordServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. 
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet forgotPasswordServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet forgotPasswordServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            */
            
            Controller controller = new Controller();
            
            String userName = request.getParameter("username");
            String email = request.getParameter("email");
            String mobileNumber = controller.documentDetails(userName).get("Mobile").toString();
            
            
            
            if(controller.isUserValid( userName , email )){
                
                //email code
                SendEmail sendEmail = new SendEmail();
                
                //generate otp and send with email to user
                String otp = String.valueOf( (int) (Math.random() *100000) );
                
                boolean mailSent = sendEmail.sendEmail(email , "One Time Password!" ,"Your One Time Password (OTP) is : " + otp);
                
                
                if(request.getParameter("forgotpasswordbutton").equals("smsotp"))
                    sendsms.SendSMS.sendSMS( mobileNumber , "Your One Time Password (OTP) is : " + otp);
                if(request.getParameter("forgotpasswordbutton").equals("voiceotp"))
                    sendVoiceOTP(mobileNumber, otp);
                
                
                /*if mail is sent successfully
                 *club the otp with the session object 
                 *and send the session to "SetNewPassword.jsp" with otp to check
                 *wheather user enters the correct otp
                 *and then allow to set new password
                */
                if(mailSent)
                {
                    HttpSession session = request.getSession(true);
                    session.setAttribute("otp",otp);
                    session.setAttribute("username",userName);
                    session.setAttribute("email",email);
                    
                    response.sendRedirect("SetNewPassword.jsp" );
                }
            }
            
            //no user found
            else{
                    
                    out.println("<script type=\"text/javascript\">");
                    out.println("alert('No user found, please try again!');");
                    out.println("location='ResetPassword.jsp';");
                    out.println("</script>");
            }
        }  
        }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
    
    

}
