package Controller;

import Connection.MyConnection;
import com.mongodb.*;


/**
 * Created by Ahuja on 05-Aug-17.
 */
public class Controller {

    public boolean loginCheck( String name , String password ){

        boolean flag = false ; //true only when login is confirmed

        //MyConnection myConnection = new MyConnection();
        MongoClient mongoClient = MyConnection.getConnection();

        //selecting database and collection
        DB db = mongoClient.getDB("test");
        DBCollection coll = db.getCollection("login");


        // creating new object
        DBObject query = new BasicDBObject("_id", name).append("password",password);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = coll.findOne(query);



        if (d1!=null){
            flag = true ;
        }


        return flag ;
    }


    public boolean registerUser(String firstName,String lastName,String name,String password){

        boolean flag = false;

        try {
            MyConnection myConnection = new MyConnection();
            MongoClient mongoClient = myConnection.getConnection();

            //selecting database and collection
            DB db = mongoClient.getDB("test");
            DBCollection dbCollection = db.getCollection("login");


            BasicDBObject doc = new BasicDBObject("_id", name).append("password", password).append("First Name", firstName).append("Last Name", lastName);

            dbCollection.insert(doc);
            System.out.println("Document inserted successfully");
            flag = true;
        }
        catch (Exception e){

        }

        return flag;
    }

    public static DBObject documentDetails(String id){
        MyConnection myConnection = new MyConnection();
        MongoClient mongoClient = myConnection.getConnection();

        //selecting database and collection
        DB db = mongoClient.getDB("test");
        DBCollection coll = db.getCollection("login");


        // creating new object
        DBObject query = new BasicDBObject("_id", id);

        // resultant document fetched by satisfying the criteria
        DBObject d1 = coll.findOne(query);

        if (d1!=null)
            return d1;
        else return null;
    }

}
